package com.edureka.capstone.order;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.client.match.MockRestRequestMatchers;
import org.springframework.test.web.client.response.MockRestResponseCreators;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class OrderServiceTest {

	//prepare mock server so no need to connect to start other service
	private MockRestServiceServer serviceServer;
	
	@Autowired
	private TestRestTemplate testRestTemplate;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Before
	public void before() {
		this.serviceServer = MockRestServiceServer.createServer(restTemplate);
	}
	
	@Test
	public void testWhenDues() {
		this.serviceServer.expect(MockRestRequestMatchers.requestTo("http://localhost:8383/payment/dues"))
		 	.andExpect(MockRestRequestMatchers.method(HttpMethod.GET))
		 	.andRespond(MockRestResponseCreators.withSuccess("100",MediaType.APPLICATION_JSON));
	}
}
