package com.edureka.capstone.order;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.Date;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.edureka.capstone.order.controller.OrderController;
import com.edureka.capstone.order.dto.OrderDTO;
import com.edureka.capstone.order.dto.OrderTransformer;
import com.edureka.capstone.order.model.Order;
import com.edureka.capstone.order.repository.OrderRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class OrderControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private OrderRepository orderRepository;
	
	@Test
	public void test() {
		Assertions.assertThat(mockMvc).isNotNull();
	}
	
	@Test
	public void testRoundTrip() throws Exception {
		OrderDTO orderDTO = OrderDTO.builder()
				.orderDate(new Date())
				.orderItemId("order.item.id")
				.customerId("customer.id")
				.fsnId("fsn.id.3")
				.gmv(100L)
				.numberOfUnits(5)
				.productMrp(20L)
				.productProcurementSla("product.procurement.sla")
				.build();
		//now convert this DTO->JSON
		ObjectMapper mapper = new ObjectMapper();
		String jsonOrderDTO = mapper.writeValueAsString(orderDTO);
		
		this.mockMvc.perform(
				post("/order")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.content(jsonOrderDTO)
		).andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string("Saved Successfully"));
		
		//check if order is saved in db
		Order expectedOrderFromDB = new OrderTransformer().to(orderDTO);
		Optional<Order> byFsnId = orderRepository.findByFsnId(expectedOrderFromDB.getFsnId());
		Assertions.assertThat(byFsnId.isPresent()).isTrue();
	}
}
