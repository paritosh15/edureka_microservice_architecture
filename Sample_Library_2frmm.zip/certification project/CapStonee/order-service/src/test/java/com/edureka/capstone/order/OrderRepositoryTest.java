package com.edureka.capstone.order;

import java.util.Date;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.edureka.capstone.order.model.Order;
import com.edureka.capstone.order.repository.OrderRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderRepositoryTest {

	@Autowired
	OrderRepository orderRepository;
	
	@Test
	public void simpleTest() {
		Order order = Order.builder()
				.orderId(1L)
				.orderDate(new Date())
				.orderItemId("order.item.id")
				.customerId("customer.id")
				.fsnId("fsn.id.1")
				.gmv(100L)
				.numberOfUnits(5)
				.productMrp(20L)
				.productProcurementSla("product.procurement.sla")
				.build();
		
		orderRepository.save(order);
		Optional<Order> byId = orderRepository.findById(1L);
		
		Assertions.assertThat(byId.isPresent()).isTrue();
		Assertions.assertThat(byId.get()).isEqualToIgnoringGivenFields(order, "orderDate");
	}
	
	@Test
	public void testIfOrderIsUpdate() {
		Order order = Order.builder()
				.orderId(1L)
				.orderDate(new Date())
				.orderItemId("order.item.id")
				.customerId("customer.id")
				.fsnId("fsn.id.3")
				.gmv(100L)
				.numberOfUnits(5)
				.productMrp(20L)
				.productProcurementSla("product.procurement.sla")
				.build();
		
		orderRepository.save(order);
		Optional<Order> byId = orderRepository.findByFsnId(order.getFsnId());
		Assertions.assertThat(byId.get()).isEqualToIgnoringGivenFields(order, "orderDate"); 
		
		order.setProductMrp(40L);
		orderRepository.save(order);
		Optional<Order> byId2 = orderRepository.findByFsnId(order.getFsnId());
		Assertions.assertThat(byId2.get()).isEqualToIgnoringGivenFields(order, "orderDate");

	}
	
	
	
}
