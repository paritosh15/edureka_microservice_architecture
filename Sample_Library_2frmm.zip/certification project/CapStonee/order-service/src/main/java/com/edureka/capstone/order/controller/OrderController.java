package com.edureka.capstone.order.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edureka.capstone.order.dto.OrderDTO;
import com.edureka.capstone.order.dto.OrderTransformer;
import com.edureka.capstone.order.model.Order;
import com.edureka.capstone.order.repository.OrderRepository;
import com.edureka.capstone.order.service.OrderService;

@RestController
@RequestMapping(path = "/order", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
public class OrderController {
	
	@Autowired
	OrderService orderService;

	@PostMapping
	public ResponseEntity saveOrder(@Valid @RequestBody OrderDTO orderDto) {
		orderService.checkDues();
		
		//convert DTO->pojo
		Order order = new OrderTransformer().to(orderDto);
		
		orderService.saveOrder(order);
		
		return ResponseEntity.ok("Saved Successfully");
	}

}
