package com.edureka.capstone.order.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name="item_order", catalog="capstone")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = "orderId")
public class Order {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="order_id")
	private Long orderId;
	
	@Column(name="order_item_id",nullable=false)
	private String orderItemId;
	
	@Column(name="fsn_id",nullable=false)
	private String fsnId;
	
	@Column(name="order_date")
	private Date orderDate;
	
	@Column(name="gmv")
	private Long gmv; //gross merchandise value
	
	@Column(name="number_of_units")
	private Integer numberOfUnits;
	
	@Column(name="sla")
	private String sla;
	
	@Column(name="customer_id",nullable=false)
	private String customerId;
	
	@Column(name="product_mrp")
	private Long productMrp;
	
	@Column(name="product_procurement_sla")
	private String productProcurementSla;
}
