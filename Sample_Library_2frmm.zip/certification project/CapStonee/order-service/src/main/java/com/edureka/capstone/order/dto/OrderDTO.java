package com.edureka.capstone.order.dto;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderDTO {

	//@NotNull
	private String orderItemId;

	//@Size(min = 3,max = 10,message = "The FSN Id should be between '3' and '10'")
	private String fsnId;

	//@Future
	private Date orderDate;

	private Long gmv;
	
	private Integer numberOfUnits;

	private String sla;

	private String customerId;

	private Long productMrp;

	private String productProcurementSla;
}
