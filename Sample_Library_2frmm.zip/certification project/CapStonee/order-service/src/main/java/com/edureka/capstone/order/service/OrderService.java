package com.edureka.capstone.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.edureka.capstone.order.model.Order;
import com.edureka.capstone.order.repository.OrderRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class OrderService {

	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	public Order saveOrder(Order order) {
		if(checkDues()) {
			//forward to clear dues page
		}else {
			//create order
			Order saved = orderRepository.save(order);
			return saved;
		}
		return null;
	}
	
	@HystrixCommand(fallbackMethod = "defaultOrderFromCache")
	public boolean checkDues() {
		ResponseEntity<String> forEntity = restTemplate.getForEntity("http://localhost:8383/payment/dues", String.class);
		String dues = forEntity.getBody();
		int iDues = Integer.parseInt(dues);
		return iDues > 0;
	}
	
	private boolean defaultOrderFromCache() {
		return false;
	}
}
