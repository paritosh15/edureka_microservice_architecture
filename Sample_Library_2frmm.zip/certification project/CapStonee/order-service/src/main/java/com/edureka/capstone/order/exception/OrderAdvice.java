package com.edureka.capstone.order.exception;

import java.sql.SQLException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class OrderAdvice {

	@ExceptionHandler(SQLException.class)
	public ResponseEntity<String> handleError(SQLException sqlException){
		return ResponseEntity.badRequest().build();
	}
}
