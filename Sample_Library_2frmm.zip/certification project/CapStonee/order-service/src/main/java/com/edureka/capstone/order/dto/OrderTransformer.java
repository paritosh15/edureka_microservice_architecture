package com.edureka.capstone.order.dto;

import com.edureka.capstone.order.model.Order;

public class OrderTransformer {

	public Order to(OrderDTO orderDTO) {
		Order order = new Order();
		
		order.setProductMrp(orderDTO.getProductMrp());
		order.setCustomerId(orderDTO.getCustomerId());
		order.setFsnId(orderDTO.getFsnId());
		order.setGmv(orderDTO.getGmv());
		order.setNumberOfUnits(orderDTO.getNumberOfUnits());
		order.setOrderDate(orderDTO.getOrderDate());
		order.setOrderItemId(orderDTO.getOrderItemId());
		order.setProductProcurementSla(orderDTO.getProductProcurementSla());
		order.setSla(orderDTO.getSla());
		
		return order;
	}
}
