package com.edureka.capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapStoneeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoneeApplication.class, args);
	}

}
